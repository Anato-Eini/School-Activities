#include <cstdlib>
#include <iostream>
#include <set>
#include "graph.h"
using namespace std;

class GraphMatrix : public Graph {
    int matrix[10][10];
    char s_vertices[10];
    int num_vert;
    int s_edges[100];
    int num_edge;

public:
    GraphMatrix() {
        num_vert = 0;
        num_edge = 0;
    }

    int numVertices() {
        return num_vert;
    }

    char* vertices() {
        if(num_vert == 0)
            return nullptr;
        char* returner = new char[num_vert];
        for(int i = 0; i < num_vert; i++)
            returner[i] = s_vertices[i];
        return returner;
    }

    int numEdges() {
        return num_edge;
    }

    int* edges() {
        return NULL;
    }

    int getEdge(char u, char v)  {
        for(int i = 0; i < num_vert; i++){
            if(s_vertices[i] == u){
                for(int j = 0; j < num_vert; j++){
                    if(s_vertices[j] == v){
                        return matrix[i][j];
                    }
                }
            }
        }
        return 0;
    }

    char* endVertices(int e)  {
        char* returner = new char [2];
        for(int i = 0; i < num_vert; i++){
            for(int j = 0; j < num_vert; j++){
                if(matrix[i][j] == e){
                    returner[0] = s_vertices[i];
                    returner[1] = s_vertices[j];
                    return returner;
                }
            }
        }
        return NULL;
    }

    char opposite(char v, int e)  {
        for(int i = 0; i < num_vert; i++){
            if(s_vertices[i] == v) {
                for (int j = 0; j < num_vert; j++) {
                    if (matrix[i][j] == e) {
                        return s_vertices[j];
                    }
                }
            }
        }
        return '-';
    }

    int outDegree(char v)  {
        int counter = 0;
        for(int i = 0; i < num_vert; i++){
            if(s_vertices[i] == v) {
                for (int j = 0; j < num_vert; j++) {
                    if (matrix[i][j] != 0) {
                        counter++;
                    }
                }
            }
        }
        return 0;
    }

    int inDegree(char v)  {
        return 0;
    }

    int* outgoingEdges(char v) {
        return NULL;
    }

    int* incomingEdges(char v) {
        return NULL;
    }

    bool insertVertex(char x)  {
        if(num_vert == 10){
            return false;
        }
        s_vertices[num_vert++] = x;
        for(int i = 0; i < num_vert; i++){
            matrix[i][num_vert - 1] = 0;
        }
        for(int i = 0; i < num_vert; i++){
            matrix[num_vert - 1][i] = 0;
        }
        return true;
    }

    bool insertEdge(char u, char v, int x)  {
        for(int i = 0; i < num_vert; i++){
            if(s_vertices[i] == u){
                for(int j = 0; j < num_vert; j++){
                    if(s_vertices[j] == v){
                        matrix[i][j] = x;
                        num_edge++;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    int removeVertex(char v) {
        return 0;
    }

    bool removeEdge(int e)  {
        return false;
    }

    void print() {
        cout << "\t";
        for (int i = 0; i < num_vert; i++) {
            cout << s_vertices[i] << "\t";
        }
        cout << endl;
        for (int i = 0; i < num_vert; i++) {
            cout << s_vertices[i] << "\t";
            for (int j = 0; j < num_vert; j++) {
                if (matrix[i][j] != 0) {
                    cout << matrix[i][j];
                }
                cout << "\t";
            }
            cout << endl;
        }
    }
};